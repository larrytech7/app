<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0"/>
    <title>error</title>
    <link rel="icon" type="image/gif" href="{{URL::to('public/images')}}/animated_favicon1.gif" />
    <!-- CSS  -->
    <link rel="stylesheet" href="{{URL::to('public/css')}}/bootstrap.min.css" />
    <link rel="stylesheet" href="{{URL::to('public/css')}}/error.css" />

</head>
<body id="four-o-four">
    <div class="container">
      <div class="col-lg-12 col-md-12 col-sm-12">
        <p>
          <h1>:(</h1>
          <h3>Sorry, we couldn't find the page you are looking for</h3>
          <a href="/" class="btn btn-large btn-primary">back to home</a>
        </p>
      </div>
    </div>

    <!--  Scripts-->
    <script type="text/javascript" src="{{URL::to('public/js')}}/jquery.js"></script>

</body>
</html>
