<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2 style="color:skyblue" >Activate Account</h2><br><br>

		<div>
			Hi {{$username}},<br>
			Welcome to <a href="#">izepay.iceteck.com</a>, please follow the link below to activate your account.<br><br>
			To activate your account, follow link: {{ $link }}.<br/>
			If you did not register at <a href="#">izepay.iceteck.com</a>, please ignore this email.<br><br>
		</div>
		<h3>izepay.iceteck.com</h3>
	</body>
</html>